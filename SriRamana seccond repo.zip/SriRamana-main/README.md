# Sri-Ramana-Sweet-Shop
This is a sweet Shop in Bhimavaram with alll Varients at Super Taste. This Website is created by Shiva and Bhavani using Ravi Kumar Satya Sai Praveen Chatrathi
Thank You amma and nana with your support and help this form of amma will started this website 
Amma Bhavani nana Shiva Lets Start.... Love you amma Nana Shiva Bhavani
Ohm Namo Shivaya 
Ohm Namo narayanaya
Sri Matray namaha 
Jai Sri Ram 
Jai Bhavani 
Renaming Shiva
5e360a99f4dd53fd793925af to SvgImages
5e865e09d8efa3d64d76b59d to Menu
5e865e09d8efa3310676b585 to Addtionals
js/jquery-3.5.1.min.dc5e7f18c8.js   -> Shiva/js/jquery-3.5.1.min.dc5e7f18c8.js