<!DOCTYPE html>
<!-- This site is Created By Shiva And Bhavani By Ravi Kumar Satya Sai Praveen as a CSP Project For Sem1 in Second year -->
<html >
    <head>
        <meta charset="utf-8">
        <title>Shiva Bhavani</title>
        <link rel="stylesheet" href="Bhavani/Additional/css/style.css">
        <link href="Bhavani/Additional/css/genaral.css" rel="stylesheet"
            type="text/css">
        <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif]-->
        
        <link
            href="Bhavani/Additional/logo_fav.png"
            rel="shortcut icon"
            she
            type="image/x-icon">
        <link href="Bhavani/Additional/logo_webclip.png" rel="apple-touch-icon">
        <link rel="stylesheet" href="Bhavani/Additional/css/import.css">
    </head>
    <body>
        <?php
        include "header.php";
        ?>
        <div id="carouselExampleCaptions" class="carousel slide carousel-fade"
            data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img
                        src="Bhavani/Additional/1.jpg"
                        class="d-block w-100"
                        alt="..."
                        style="height: auto; width: 100%;">
                </div>
                <div class="carousel-item">
                    <img
                        src="Bhavani/Additional/2.jpg"
                        class="d-block w-100"
                        alt="..."
                        style="height: auto; width: 100%;">
                </div>
                <div class="carousel-item">
                    <img
                        src="Bhavani/Additional/3.jpg"
                        class="d-block w-100"
                        alt="..."
                        style="height: auto; width: 100%;">
                </div>
            </div>
            <a
                class="carousel-control-prev"
                href="#carouselExampleCaptions"
                role="button"
                data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a
                class="carousel-control-next"
                href="#carouselExampleCaptions"
                role="button"
                data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <div class="content-section-bg">
            <div class="container">
                <div class="w-layout-grid content-grid">
                    <div class="content-block bg-text">
                        <h2>
                            The home of
                            <br>
                            Fresh Sweets
                        </h2>
                        <p>
                            We are Preparing Sweets from Generations.
                            <br>
                            This shop is famously known as
                            <b style="color: rgb(35, 230, 224);"> DNR PENKUTILLU</b>
                            <br>
                            We will Provide the Best at affortable price
                        </p>
                        <a href="company.html" class="button button-space
                            w-button">Learn about us</a>
                    </div>
                    <div class="image-block">
                        <img
                            src="Bhavani/Additional/shop.png"
                            srcset="Bhavani/Additional/shop-p-500.png
                            500w, Bhavani/Additional/shop.png
                            523w"
                            sizes="(max-width: 556px) 94vw, 523px"
                            alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="content-section">
            <div class="container">
                <div class="title-wrap-centre">
                    <h2>We Previous You</h2>
                </div>
                <div class="w-layout-grid works-grid">
                    <div class="content-card">
                        <img src="Bhavani/Additional/Sweets.png" alt=""
                            class="step-image">
                        <div class="content-wrapper">
                            <h5>Tasty Sweets are Wating for you</h5>
                            <p>
                                Tast the wonderfull sweets prepared with
                                pure organic gee and other ingeidance.
                            </p>
                        </div>
                    </div>
                    <div class="line-column">
                        <div class="line"></div>
                    </div>
                    <div class="content-card">
                        <img src="Bhavani/Additional/Snaks.png" alt=""
                            class="step-image">
                        <div class="content-wrapper">
                            <h5>Taste the Crispy Snacks</h5>
                            <p>
                                we are preparing n varites of snaks in a higenic
                                envirolment.
                                Taste the best with Sri Ramana.
                            </p>
                        </div>
                    </div>
                    <div class="line-column">
                        <div class="line"></div>
                    </div>
                    <div class="content-card">
                        <img src="Bhavani/Additional/preorder.png" alt=""
                            class="step-image">
                        <div class="content-wrapper">
                            <h5>Clebrate With Sri Ramana</h5>
                            <p>
                                We will supply sweets and Snacks to events and
                                Functions
                                you can Pre Booking Sweets and Snacks
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-section-bg">
            <div class="container">
                <div class="title-wrap-centre">
                    <h2>Browse our menu</h2>
                    <p>
                        Use our menu to place an online order, or
                        <a href="#">phone</a> or
                        our
                        store to
                        <br>
                        place an order. Fast
                        and fresh food.
                    </p>
                </div>
                <div class="w-tabs">
                    <div class="tab-menu-round w-tab-menu">
                        <a class="tab-link-round w-inline-block w-tab-link
                            w--current">
                            <div>Sweets</div>
                        </a>
                        <a class="tab-link-round w-inline-block
                            w-tab-link">
                            <div>Snacks</div>
                        </a>
                        <a class="tab-link-round w-inline-block
                            w-tab-link">
                            <div>Pre Ordered</div>
                        </a>
                    </div>
                    <div class="w-tab-content">
                        <div class="tab-pane-wrap w-tab-pane
                            w--tab-active">
                            <div class="w-dyn-list">
                                <div role="list" class="order-collection
                                    w-dyn-items w-row">
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a href="product/burger-dreams.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa3676276b5cd_Burger 03.png"
                                                    alt="" class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/burger-dreams.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Burger Dreams</h6>
                                                    <div class="price">$ 9.20
                                                        USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div>
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a href="product/burger-waldo.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa3b2e676b5b5_Burger%2008.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/burger-waldo.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Burger Waldo</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 10.00
                                                        USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa36db276b633"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa3baa276b632"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a href="product/burger-cali.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa36d8576b5b4_Burger%2004.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/burger-cali.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Burger Cali</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 8.00 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa3c35476b631"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa37e2276b630"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a
                                                href="product/burger-bacon-buddy.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa3650476b5b3_Burger%2006.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/burger-bacon-buddy.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Burger Bacon Buddy</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 9.99 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa34a1f76b62f"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa3313076b62e"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a href="product/burger-spicy.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa33f0276b5b2_Burger%2002.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/burger-spicy.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Burger Spicy</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 9.20 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa34e8676b62c"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa3609c76b61b"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a
                                                href="product/burger-classic.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa343f176b5b1_Burger%2001.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/burger-classic.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Burger Classic</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 8.00 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa36e2876b5cc"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa3000f76b5b9"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div data-w-tab="Sides" class="w-tab-pane">
                            <div class="w-dyn-list">
                                <div role="list" class="order-collection
                                    w-dyn-items w-row">
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a href="product/salad-ceaser.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa30d7276b5ac_Side%2006.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/salad-ceaser.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Salad Ceaser</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 6.00 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa339e576b63d"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa3751e76b63c"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a
                                                href="product/beans-slow-cooked.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa360e276b609_Side%2005.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/beans-slow-cooked.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Beans Slow Cooked</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 4.00 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa331c876b63b"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa371f176b63a"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a href="product/fries-cheese.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa352fc76b5e1_Side%2002.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/fries-cheese.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Fries Cheese</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 5.00 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa3261576b639"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa3a3b676b638"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a href="product/fries-rustic.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa33ebb76b5f5_Side%2003.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/fries-rustic.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Fries Rustic</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 4.00 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa34f1076b637"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa3281176b636"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div data-w-tab="Drinks" class="w-tab-pane">
                            <div class="w-dyn-list">
                                <div role="list" class="order-collection
                                    w-dyn-items w-row">
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a
                                                href="product/drink-fig-lime.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa3409976b5b0_Drink%201.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/drink-fig-lime.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Drink Fig &amp; Lime</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 4.00 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa32f4f76b645"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa3bec576b644"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a href="product/drink-liquor.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa30dc176b5af_Drink%202.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/drink-liquor.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Drink Liquor</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 7.00 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa34fab76b643"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa3c6a876b642"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a href="product/drink-lime.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa3f65176b5ae_Drink%204.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/drink-lime.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Drink Lime</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 4.00 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa336d476b641"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa30dae76b640"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="menu-item
                                        w-dyn-item w-col
                                        w-col-6">
                                        <div class="food-card">
                                            <a href="product/drink-cola.html"
                                                class="food-image-square
                                                w-inline-block">
                                                <img
                                                    src="Bhavani/Menu/5e865e09d8efa3145f76b5ad_Drink%203.png"
                                                    data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_main_image_4dr%22%2C%22to%22%3A%22src%22%7D%5D"
                                                    alt=""
                                                    class="food-image">
                                            </a>
                                            <div class="food-card-content">
                                                <a
                                                    href="product/drink-cola.html"
                                                    class="food-title-wrap
                                                    w-inline-block">
                                                    <h6>Drink Cola</h6>
                                                    <div
                                                        data-wf-sku-bindings="%5B%7B%22from%22%3A%22f_price_%22%2C%22to%22%3A%22innerHTML%22%7D%5D"
                                                        class="price">$ 3.00 USD</div>
                                                </a>
                                                <p class="paragraph">
                                                    Lorem Ipsum is simply dummy
                                                    text of
                                                    the printing and typesetting
                                                    industry.
                                                </p>
                                                <div class="add-to-cart">
                                                    <form
                                                        data-node-type="commerce-add-to-cart-form"
                                                        data-commerce-sku-id="5e865e09d8efa34b1176b63f"
                                                        data-loading-text="Adding
                                                        to cart..."
                                                        data-commerce-product-id="5e865e09d8efa347b876b63e"
                                                        class="w-commerce-commerceaddtocartform
                                                        default-state">
                                                        <input
                                                            type="number"
                                                            pattern="^[0-9]+$"
                                                            inputmode="numeric"
                                                            id="quantity-77d000eb734842aa4cf87b0bb03800c1"
                                                            name="commerce-add-to-cart-quantity-input"
                                                            min="1"
                                                            class="w-commerce-commerceaddtocartquantityinput
                                                            quantity"
                                                            value="1">
                                                        <input
                                                            type="submit"
                                                            value="Add to Cart"
                                                            data-node-type="commerce-add-to-cart-button"
                                                            data-loading-text="Adding
                                                            to cart..."
                                                            aria-busy="false"
                                                            aria-haspopup="dialog"
                                                            class="w-commerce-commerceaddtocartbutton
                                                            order-button">
                                                    </form>
                                                    <div style="display:none"
                                                        class="w-commerce-commerceaddtocartoutofstock
                                                        out-of-stock-state">
                                                        <div>This product is out
                                                            of stock.</div>
                                                    </div>
                                                    <div
                                                        data-node-type="commerce-add-to-cart-error"
                                                        style="display:none"
                                                        class="w-commerce-commerceaddtocarterror">
                                                        <div
                                                            data-node-type="commerce-add-to-cart-error"
                                                            data-w-add-to-cart-quantity-error="Product
                                                            is not
                                                            available in this
                                                            quantity."
                                                            data-w-add-to-cart-general-error="Something
                                                            went
                                                            wrong when adding
                                                            this item to the
                                                            cart."
                                                            data-w-add-to-cart-mixed-cart-error="You
                                                            can’t
                                                            purchase another
                                                            product with a
                                                            subscription."
                                                            data-w-add-to-cart-buy-now-error="Something
                                                            went
                                                            wrong when trying to
                                                            purchase this item."
                                                            data-w-add-to-cart-checkout-disabled-error="Checkout
                                                            is disabled on this
                                                            site."
                                                            data-w-add-to-cart-select-all-options-error="Please
                                                            select an option in
                                                            each set.">
                                                            Product
                                                            is not available in
                                                            this quantity.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div style="-webkit-transform:translate3d(-25PX, 0, 0)
                    scale3d(1, 1, 1)
                    rotateX(0) rotateY(0) rotateZ(0) skew(0,
                    0);-moz-transform:translate3d(-25PX, 0, 0) scale3d(1, 1, 1)
                    rotateX(0)
                    rotateY(0) rotateZ(0) skew(0,
                    0);-ms-transform:translate3d(-25PX, 0,
                    0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0,
                    0);transform:translate3d(-25PX, 0, 0) scale3d(1, 1, 1)
                    rotateX(0)
                    rotateY(0) rotateZ(0) skew(0, 0);opacity:0"
                    class="button-wrapper">
                    <a href="order.html" class="button w-button">
                        See
                        Full Menu
                    </a>
                </div>
            </div>
        </div>
        <div class="content-section">
            <div class="container">
                <div class="w-layout-grid content-grid">
                    <div class="image-block">
                        <img
                            src="Bhavani/Additional/5e865e09d8efa379a976b602_Phones.png"
                            srcset="Bhavani/Additional/5e865e09d8efa379a976b602_Phones-p-500.png
                            500w,
                            Bhavani/Additional/5e865e09d8efa379a976b602_Phones-p-800.png
                            800w,
                            Bhavani/Additional/5e865e09d8efa379a976b602_Phones.png
                            2103w"
                            sizes="94vw"
                            alt="">
                        <img
                            src="Bhavani/Additional/5e865e09d8efa3241b76b605_Content%20Pattern.svg"
                            alt="" class="pattern">
                    </div>
                    <div class="content-block">
                        <h2>Order online with our simple checkout.</h2>
                        <p>
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting
                            industry. Lorem Ipsum has been the
                            industry&#x27;s standard dummy text ever since the
                            1500.
                        </p>
                        <a href="faq.html" class="button button-space w-button">See
                            our FAQ</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-section-bg">
            <div class="container">
                <div class="w-layout-grid content-grid">
                    <div class="content-block bg-text">
                        <h2>Call our store and takeaway when it suits you best.</h2>
                        <p>
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting
                            industry. Lorem Ipsum has been the
                            industry&#x27;s standard dummy text ever since the
                            1500.
                        </p>
                        <a href="#" class="button button-space w-button">Ph. +61
                            233 2333</a>
                    </div>
                    <div class="image-block">
                        <img
                            src="Bhavani/Additional/5eb0bcb8036072a55de52baf_Food%20Takeaway.png"
                            alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="cta-section">
            <div class="w-layout-grid cta-grid">
                <div class="cta-image"></div>
                <div class="cta-content">
                    <h1 class="cta-heading">
                        <span class="dark-span">Support</span>
                        good
                        food
                        <br>
                        and local business.
                    </h1>
                    <a href="order.html" class="button-white button-space
                        w-button">
                        Order
                        Now
                    </a>
                </div>
            </div>
        </div>
        
        <?php include "fotter.php"  ?>
    
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
            integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
            crossorigin="anonymous"></script>
        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
            crossorigin="anonymous"></script>
        <script
            src="js/jquery-3.5.1.min.dc5e7f18c8.js?site=Bhavani/Additional"
            type="text/javascript"
            integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
            crossorigin="anonymous"></script>
        <script src="Bhavani/Additional/js/webflow.bad13ffae.js"
            type="text/javascript"></script>
    </body>
</html>
