<div class="footer">
      <div class="container">
        <div class="w-layout-grid footer-grid">
          <div id="w-node-_67f7db32-28d2-9f37-8b84-a159dcc6da5a-dcc6da57"
            class="footer-column"><img
              src="Bhavani/Additional/Logo.svg"
              width="40" alt="" class="footer-logo">
            <p>Takeaway &amp; Delivery template<br>for small - medium
              businesses. </p>
          </div>
          <div id="w-node-_67f7db32-28d2-9f37-8b84-a159dcc6da5e-dcc6da57"
            class="footer-column">
            <div class="title">company</div><a href="index.htm"
              aria-current="page"
              class="footer-link w--current">Home</a><a href="order.html"
              class="footer-link">Order</a><a href="faq.html"
              class="footer-link">FAQ</a><a
              href="mailto:hello@website.com?subject=Hi" class="footer-link">Contact</a>
          </div>
          <div id="w-node-_67f7db32-28d2-9f37-8b84-a159dcc6da69-dcc6da57"
            class="footer-column">
            <div class="title">TEMPLATE</div><a href="template/styleguide.html"
              class="footer-link">Style Guide</a><a
              href="template/changelog.html" class="footer-link">Changelog</a><a
              href="template/licence.html"
              class="footer-link">Licence</a><a
              href="https://university.webflow.com/" target="_blank"
              class="footer-link">Webflow University</a>
          </div>
          <div id="w-node-_67f7db32-28d2-9f37-8b84-a159dcc6da72-dcc6da57"
            class="footer-column">
            <div class="title">FLOWBASE </div><a href="http://www.flowbase.co"
              target="_blank" class="footer-link">More
              Cloneables</a>
          </div>
        </div>
        <div class="footer-legal">
          <div class="footer-detail-left">
            <div class="legal">Built by <a href="http://www.flowbase.co"
                target="_blank" class="webflow-link">Flowbase</a>
              · Powered by <a href="http://webflow.com/" target="_blank"
                class="webflow-link">Webflow</a></div>
          </div>
          <div class="footer-detail-right">
            <div class="social-icon-wrap"><a href="#" class="social-link
                w-inline-block"><img
                  src="Bhavani/Svgs/instagram.svg"
                  alt=""
                  class="social-icon"></a><a href="#" class="social-link
                w-inline-block"><img
                  src="Bhavani/Svgs/twitter.svg"
                  alt=""
                  class="social-icon"></a><a href="#" class="social-link
                w-inline-block"><img
                  src="Bhavani/Svgs/youtube.svg"
                  alt=""
                  class="social-icon"></a></div>
          </div>
        </div>
      </div>
    </div>